function tg=tgear(thtl)
if(thtl<=.77)
 tg=64.94*thtl;
else
 tg=217.38*thtl-117.38;
end

