function cyy=cy(beta,ail,rdr)
% Body-axis y Force
cyy=-.02*beta+.021*(ail/20)+.086*(rdr/30);
end
