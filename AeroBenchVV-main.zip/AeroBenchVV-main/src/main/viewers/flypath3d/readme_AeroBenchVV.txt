Please note that this is a modified version of flypath3d. The original (and full) version of the flypath3d library can be found for free online.

Modifications:
Deleted unused models and examples
Enabled a fixed zoom (rather than autofit)
Added F-16 simulation-specific text overlays with state data
Tailored "flypath.m" to fit the needs of AeroBenchVV in other minor ways.

The library is called in the functions "makeAnimation.m" and "makePicture.m" in the F16Sim directory.